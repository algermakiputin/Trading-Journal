import React from 'react'

class Analytics extends React.Component {

    render() {

        return null
    }
}

export default Analytics