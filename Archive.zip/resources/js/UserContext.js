import React from 'react'

const name = "alger"
const UserContext = React.createContext({
    name: name
});

export default UserContext;