global.server_date = document.getElementsByName('server-date')[0].getAttribute('content');
global.csrf_token = document.getElementsByName("csrf-token")[0].getAttribute("content");
global.user_name = document.getElementsByName("user-name")[0].getAttribute("content");
global.user_email = document.getElementsByName("user-email")[0].getAttribute("content");