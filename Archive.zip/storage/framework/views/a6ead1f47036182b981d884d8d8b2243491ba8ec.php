<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Hero Journal</title> 
        <meta name="server-date" content="<?php echo date('Y-m-d') ?>" >
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="user-email" content="<?php echo e(Auth()->user()->email); ?>" >
        <meta name="user-name" content="<?php echo e(Auth()->user()->name); ?>" >
        <link rel="icon" href="<?php echo e(asset('images/ico.png')); ?>">
    </head>
    <body class="antialiased"> 
        <div id="example"></div>
    </body> 
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</html>
<?php /**PATH /Users/algermakiputin/Documents/Projects/Trading-Journal/resources/views/welcome.blade.php ENDPATH**/ ?>